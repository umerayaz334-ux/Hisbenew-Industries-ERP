import{d as e,g as t,m as n,n as r,r as i,s as a}from"./index-BPSnkaC0.js";var o=t(),s=a(),c=e=>Number(e||0).toLocaleString(`en-PK`,{minimumFractionDigits:2,maximumFractionDigits:2}),l=e=>Number(e||0).toFixed(2),u=()=>{let e=window.location.pathname.match(/^\/portal\/suppliers\/(\d+)\/ledger\/?$/);return e?Number(e[1]):null},d=(e={})=>{if(!e.faulty)return 0;let t=Math.max(Number(e.quantity||0),0),n=Math.max(Number(e.faulty_quantity||0),0);return Math.min(n,t)},f=(e={})=>{let t=Math.max(Number(e.quantity||0),0);return Math.max(t-d(e),0)},p=e=>String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`),m=e=>String(e||`supplier`).trim().replace(/[^a-z0-9-_]+/gi,`-`).replace(/^-+|-+$/g,``).toLowerCase()||`supplier`,h=e=>{if(!e)return[];let t=(e.stock_movements||[]).filter(e=>e.movement_type===`Supplier Purchase`).map(e=>{let t=Math.max(Number(e.quantity||0),0),r=f(e),i=Number(e.purchase_price||0),a=i*r,o=t-r;return{id:`stock-${e.id}`,balanceDelta:a,credit:a,date:e.created_at,debit:0,ledgerType:`Stock added`,note:o>0?`Faulty deducted: ${o}`:e.note||``,quantity:t,quantityLabel:r<t?`${r}/${t}`:String(t),reference:e.reference||e.source||`-`,sku:e.article_no||`-`,sourceType:`stock`,thumbnailUrl:n(e.product_image_url),total:a,unitPrice:i}}),r=(e.supply_items||[]).map(e=>{let t=Math.max(Number(e.quantity||0),0),n=Number(e.unit_price||0),r=Number(e.line_total||t*n);return{id:`supply-${e.id}`,balanceDelta:r,credit:r,date:e.created_at,debit:0,ledgerType:`Supplies / accessories`,note:e.note||e.usage_area||``,quantity:t,quantityLabel:String(t),reference:e.sku||e.category||`-`,sku:e.item_name||`-`,sourceType:`supply`,thumbnailUrl:null,total:r,unitPrice:n}}),a=(e.payments||[]).map(e=>{let t=Number(e.amount||0);return{id:`payment-${e.id}`,balanceDelta:-t,credit:0,date:e.payment_date||e.created_at,debit:t,ledgerType:`Payment`,note:e.note||``,quantity:0,quantityLabel:`-`,reference:e.payment_reference||e.payment_method||`-`,sku:`-`,sourceType:`payment`,thumbnailUrl:null,total:t,unitPrice:0}}),o=(e.transactions||[]).map(e=>{let t=Number(e.amount||0);return{id:`transaction-${e.id}`,balanceDelta:t,credit:t>0?t:0,date:e.created_at,debit:t<0?Math.abs(t):0,ledgerType:e.transaction_type||`Adjustment`,note:e.note||``,quantity:0,quantityLabel:`-`,reference:e.reference||`-`,sku:`-`,sourceType:t>=0?`credit`:`debit`,thumbnailUrl:null,total:Math.abs(t),unitPrice:0}}),s=0;return[...t,...r,...a,...o].sort((e,t)=>(i(e.date)?.getTime()||0)-(i(t.date)?.getTime()||0)).map(e=>(s+=e.balanceDelta,{...e,balance:s}))},g=()=>{let[t,n]=(0,o.useState)(null),[i,a]=(0,o.useState)(!0),[d,f]=(0,o.useState)(``),g=u();(0,o.useEffect)(()=>{let t=!0;if(!g){f(`Account ledger link is invalid.`),a(!1);return}return a(!0),e.get(`/suppliers/${g}`).then(e=>{t&&(n(e.data),f(``))}).catch(e=>{console.error(`Supplier ledger error:`,e),t&&f(e.response?.data?.detail||`Account ledger could not be loaded.`)}).finally(()=>{t&&a(!1)}),()=>{t=!1}},[g]);let _=(0,o.useMemo)(()=>h(t),[t]),v=(0,o.useMemo)(()=>_.reduce((e,t)=>({credit:e.credit+Number(t.credit||0),debit:e.debit+Number(t.debit||0),stockQuantity:e.stockQuantity+(t.sourceType===`stock`?Number(t.quantity||0):0)}),{credit:0,debit:0,stockQuantity:0}),[_]);return(0,s.jsxs)(`main`,{className:`supplier-ledger-page`,children:[(0,s.jsxs)(`header`,{className:`supplier-ledger-header`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{className:`supplier-ledger-kicker`,children:`Account ledger`}),(0,s.jsx)(`h1`,{children:t?.name||`Account ledger`}),(0,s.jsx)(`p`,{children:`Stock additions, payments, and adjustments with running balance.`})]}),(0,s.jsxs)(`div`,{className:`supplier-ledger-actions`,children:[(0,s.jsx)(`button`,{className:`supplier-ledger-secondary`,onClick:()=>window.close(),type:`button`,children:`Close tab`}),(0,s.jsx)(`button`,{className:`supplier-ledger-primary`,disabled:!_.length,onClick:()=>{let e=r(new Date().toISOString()),n=_.map(e=>{let t=e.sourceType===`stock`?e.thumbnailUrl?`<img src="${p(e.thumbnailUrl)}" width="54" height="54" style="width:54px;height:54px;display:block;margin:0 auto;border:1px solid #d9dee5;" />`:`<span class="thumb-empty">No image</span>`:``;return`
          <tr class="ledger-row ${p(e.sourceType)}" style="height:50pt;mso-height-source:userset;">
            <td>${p(r(e.date))}</td>
            <td><span class="type-pill ${p(e.sourceType)}">${p(e.ledgerType)}</span></td>
            <td class="thumb-cell" align="center" valign="middle" style="width:62pt;height:50pt;padding:4px;text-align:center;vertical-align:middle;">${t}</td>
            <td style="mso-number-format:'\\@';">${p(e.sku)}</td>
            <td>${p(e.quantityLabel)}</td>
            <td class="money">${e.unitPrice?l(e.unitPrice):``}</td>
            <td class="money">${l(e.total)}</td>
            <td class="money debit">${e.debit?l(e.debit):``}</td>
            <td class="money credit">${e.credit?l(e.credit):``}</td>
            <td class="money balance">${l(e.balance)}</td>
            <td>${p(e.reference)}</td>
            <td>${p(e.note)}</td>
          </tr>`}).join(``),i=`<!doctype html>
      <html xmlns:o="urn:schemas-microsoft-com:office:office"
        xmlns:x="urn:schemas-microsoft-com:office:excel"
        xmlns="http://www.w3.org/TR/REC-html40">
        <head>
          <meta charset="utf-8" />
          <!--[if gte mso 9]>
          <xml>
            <x:ExcelWorkbook>
              <x:ExcelWorksheets>
                <x:ExcelWorksheet>
                  <x:Name>Account Ledger</x:Name>
                  <x:WorksheetOptions>
                    <x:FreezePanes/>
                    <x:FrozenNoSplit/>
                    <x:SplitHorizontal>7</x:SplitHorizontal>
                    <x:TopRowBottomPane>7</x:TopRowBottomPane>
                    <x:DisplayGridlines/>
                  </x:WorksheetOptions>
                </x:ExcelWorksheet>
              </x:ExcelWorksheets>
            </x:ExcelWorkbook>
          </xml>
          <![endif]-->
          <style>
            body {
              margin: 0;
              background: #f5f7fa;
              color: #1f2937;
              font-family: "Segoe UI", Arial, sans-serif;
            }

            table {
              border-collapse: collapse;
              font-family: "Segoe UI", Arial, sans-serif;
            }

            .sheet {
              width: 100%;
            }

            .hero td {
              padding: 18px 20px;
              border: 0;
              background: #1f2937;
              color: #ffffff;
            }

            .hero-title {
              font-size: 22pt;
              font-weight: 700;
              line-height: 1.1;
            }

            .hero-subtitle {
              margin-top: 5px;
              color: #dbe4ee;
              font-size: 10pt;
            }

            .spacer td {
              height: 10pt;
              border: 0;
              background: #f5f7fa;
            }

            .summary td {
              padding: 10px 12px;
              border: 1px solid #d7dde5;
              background: #ffffff;
            }

            .summary-label {
              color: #64748b;
              font-size: 8pt;
              font-weight: 700;
              text-transform: uppercase;
            }

            .summary-value {
              margin-top: 4px;
              color: #111827;
              font-size: 14pt;
              font-weight: 700;
              mso-number-format: "#,##0.00";
            }

            .ledger-table {
              width: 100%;
              table-layout: fixed;
            }

            .ledger-table th {
              height: 25pt;
              padding: 7px 8px;
              border: 1px solid #111827;
              background: #111827;
              color: #ffffff;
              font-size: 8pt;
              font-weight: 700;
              text-align: left;
              vertical-align: middle;
            }

            .ledger-table td {
              height: 50pt;
              padding: 7px 8px;
              border: 1px solid #d7dde5;
              background: #ffffff;
              color: #1f2937;
              font-size: 9pt;
              vertical-align: middle;
              mso-height-source: userset;
            }

            .ledger-row:nth-child(even) td {
              background: #f9fbfd;
            }

            .ledger-row.payment td {
              background: #fff7ed !important;
              border-color: #f0d7bd;
            }

            .ledger-row.debit td {
              background: #fff1f1 !important;
              border-color: #efcaca;
            }

            .ledger-row.credit td {
              background: #f0f8f3 !important;
              border-color: #cfe7d6;
            }

            .thumb-cell {
              width: 62pt;
              height: 50pt;
              padding: 4px !important;
              text-align: center;
              vertical-align: middle;
              mso-width-source: userset;
              mso-height-source: userset;
            }

            .thumb-empty {
              display: block;
              width: 54px;
              height: 54px;
              margin: 0 auto;
              border: 1px solid #d9dee5;
              background: #eef2f6;
              color: #7a8491;
              font-size: 7pt;
              line-height: 54px;
              text-align: center;
            }

            .type-pill {
              display: inline-block;
              padding: 3px 7px;
              border: 1px solid #cfd7e1;
              background: #eef2f6;
              color: #334155;
              font-size: 8pt;
              font-weight: 700;
            }

            .type-pill.stock,
            .type-pill.credit,
            .credit {
              color: #17613a;
            }

            .type-pill.payment,
            .type-pill.debit,
            .debit {
              color: #92402f;
            }

            .money {
              text-align: right;
              mso-number-format: "#,##0.00";
            }

            .balance {
              font-weight: 700;
              background: #f3f6f9 !important;
            }
          </style>
        </head>
        <body>
          <table class="sheet">
            <tr class="hero">
              <td colspan="12">
                <div class="hero-title">${p(t?.name||`Supplier`)} Ledger</div>
                <div class="hero-subtitle">Generated ${p(e)} / ${_.length} entries</div>
              </td>
            </tr>
            <tr class="spacer"><td colspan="12"></td></tr>
          </table>

          <table class="summary">
            <tr>
              <td>
                <div class="summary-label">Stock quantity</div>
                <div class="summary-value">${v.stockQuantity}</div>
              </td>
              <td>
                <div class="summary-label">Debit (PKR)</div>
                <div class="summary-value">${l(v.debit)}</div>
              </td>
              <td>
                <div class="summary-label">Credit (PKR)</div>
                <div class="summary-value">${l(v.credit)}</div>
              </td>
              <td>
                <div class="summary-label">Balance (PKR)</div>
                <div class="summary-value">${l(t?.balance_due)}</div>
              </td>
            </tr>
          </table>

          <table class="sheet">
            <tr class="spacer"><td colspan="12"></td></tr>
          </table>

          <table class="ledger-table">
            <col style="width:120pt" />
            <col style="width:95pt" />
            <col style="width:62pt" />
            <col style="width:90pt" />
            <col style="width:58pt" />
            <col style="width:78pt" />
            <col style="width:86pt" />
            <col style="width:86pt" />
            <col style="width:86pt" />
            <col style="width:92pt" />
            <col style="width:110pt" />
            <col style="width:180pt" />
            <thead>
              <tr>
                <th>Date</th>
                <th>Ledger type</th>
                <th>Thumbnail</th>
                <th>SKU</th>
                <th>Qty</th>
                <th>Unit (PKR)</th>
                <th>Total (PKR)</th>
                <th>Debit (PKR)</th>
                <th>Credit (PKR)</th>
                <th>Balance (PKR)</th>
                <th>Reference</th>
                <th>Note</th>
              </tr>
            </thead>
            <tbody>${n}</tbody>
          </table>
        </body>
      </html>`,a=new Blob([`﻿`,i],{type:`application/vnd.ms-excel;charset=utf-8`}),o=URL.createObjectURL(a),s=document.createElement(`a`),c=new Date().toISOString().slice(0,10);s.href=o,s.download=`${m(t?.name)}-ledger-${c}.xls`,document.body.appendChild(s),s.click(),s.remove(),URL.revokeObjectURL(o)},type:`button`,children:`Export Excel`}),(0,s.jsx)(`button`,{className:`supplier-ledger-primary`,disabled:!_.length,onClick:()=>{let e=r(new Date().toISOString()),n=`${t?.name||`Account`} Ledger`,i=_.map(e=>{let t=e.sourceType===`stock`?`<div class="product-cell">${e.thumbnailUrl?`<img class="product-thumb" src="${p(e.thumbnailUrl)}" alt="${p(e.sku)}" />`:`<span class="product-thumb empty">No image</span>`}<strong>${p(e.sku)}</strong></div>`:`<span class="event-product-cell">-</span>`,n=e.sourceType===`payment`?`debit`:`credit`;return`
          <tr class="${p(e.sourceType)}-row">
            <td class="date-cell">${p(r(e.date))}</td>
            <td><span class="type-chip ${p(n)}">${p(e.ledgerType)}</span></td>
            <td>${t}</td>
            <td class="number-cell">${p(e.quantityLabel)}</td>
            <td class="money-cell">${e.unitPrice?`PKR ${p(c(e.unitPrice))}`:`-`}</td>
            <td class="money-cell">PKR ${p(c(e.total))}</td>
            <td class="money-cell debit-text">${e.debit?`PKR ${p(c(e.debit))}`:`-`}</td>
            <td class="money-cell credit-text">${e.credit?`PKR ${p(c(e.credit))}`:`-`}</td>
            <td class="money-cell balance-cell">PKR ${p(c(e.balance))}</td>
            <td>
              <strong class="reference-text">${p(e.reference)}</strong>
              ${e.note?`<small>${p(e.note)}</small>`:``}
            </td>
          </tr>`}).join(``),a=`<!doctype html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>${p(n)}</title>
          <style>
            @page {
              size: A4 landscape;
              margin: 10mm;
            }

            * {
              box-sizing: border-box;
            }

            body {
              margin: 0;
              background: #eef1f5;
              color: #1f2937;
              font-family: "Segoe UI", Arial, sans-serif;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }

            .print-shell {
              width: 277mm;
              min-height: 190mm;
              margin: 0 auto;
              padding: 12mm;
              background: #ffffff;
            }

            .print-toolbar {
              display: flex;
              justify-content: flex-end;
              gap: 8px;
              margin-bottom: 10px;
            }

            .print-toolbar button {
              min-height: 34px;
              padding: 0 12px;
              border: 1px solid #2f3338;
              border-radius: 4px;
              background: #2f3338;
              color: #ffffff;
              cursor: pointer;
              font-size: 12px;
              font-weight: 700;
            }

            .pdf-header {
              display: grid;
              grid-template-columns: minmax(0, 1fr) auto;
              gap: 18px;
              align-items: end;
              padding-bottom: 12px;
              border-bottom: 2px solid #1f2937;
            }

            .pdf-kicker {
              color: #64748b;
              font-size: 9px;
              font-weight: 800;
              letter-spacing: 0.6px;
              text-transform: uppercase;
            }

            h1 {
              margin: 4px 0 0;
              color: #111827;
              font-size: 24px;
              line-height: 1.05;
            }

            .pdf-meta {
              margin-top: 6px;
              color: #64748b;
              font-size: 11px;
            }

            .balance-box {
              min-width: 190px;
              padding: 10px 12px;
              border: 1px solid #d7dde5;
              border-radius: 6px;
              background: #f8fafc;
              text-align: right;
            }

            .balance-box span {
              display: block;
              color: #64748b;
              font-size: 9px;
              font-weight: 800;
              text-transform: uppercase;
            }

            .balance-box strong {
              display: block;
              margin-top: 4px;
              color: #111827;
              font-size: 18px;
            }

            .summary-grid {
              display: grid;
              grid-template-columns: repeat(4, minmax(0, 1fr));
              gap: 8px;
              margin: 12px 0;
            }

            .summary-card {
              min-height: 54px;
              padding: 9px 10px;
              border: 1px solid #d7dde5;
              border-radius: 6px;
              background: #f9fbfd;
            }

            .summary-card span {
              display: block;
              color: #64748b;
              font-size: 9px;
              font-weight: 800;
              text-transform: uppercase;
            }

            .summary-card strong {
              display: block;
              margin-top: 4px;
              color: #111827;
              font-size: 14px;
            }

            table {
              width: 100%;
              border-collapse: collapse;
              table-layout: fixed;
            }

            thead {
              display: table-header-group;
            }

            tr {
              break-inside: avoid;
              page-break-inside: avoid;
            }

            th {
              padding: 8px 7px;
              border: 1px solid #111827;
              background: #111827;
              color: #ffffff;
              font-size: 9px;
              font-weight: 800;
              text-align: left;
              text-transform: uppercase;
            }

            td {
              padding: 7px;
              border: 1px solid #d9dee5;
              color: #1f2937;
              font-size: 10px;
              line-height: 1.35;
              vertical-align: middle;
            }

            tbody tr:nth-child(even) td {
              background: #f8fafc;
            }

            tbody tr.payment-row td {
              background: #fff7ed;
              border-color: #f0d7bd;
            }

            tbody tr.debit-row td {
              background: #fff1f1;
              border-color: #efcaca;
            }

            tbody tr.credit-row td {
              background: #f0f8f3;
              border-color: #cfe7d6;
            }

            small {
              display: block;
              margin-top: 3px;
              color: #64748b;
              font-size: 8.5px;
              line-height: 1.35;
            }

            .date-cell {
              width: 92px;
            }

            .product-cell {
              display: grid;
              grid-template-columns: 42px minmax(0, 1fr);
              align-items: center;
              gap: 7px;
            }

            .product-thumb {
              display: block;
              width: 42px;
              height: 42px;
              border: 1px solid #cfd7e1;
              border-radius: 5px;
              background: #eef2f6;
              object-fit: cover;
            }

            .product-thumb.empty {
              display: grid;
              place-items: center;
              color: #7a8491;
              font-size: 7px;
              font-weight: 800;
              line-height: 1.1;
              text-align: center;
            }

            .product-cell strong,
            .reference-text,
            .event-product-cell {
              color: #111827;
              font-size: 10px;
              font-weight: 800;
              overflow-wrap: anywhere;
            }

            .type-chip {
              display: inline-flex;
              min-height: 22px;
              align-items: center;
              padding: 0 7px;
              border: 1px solid #cfd7e1;
              border-radius: 999px;
              background: #ffffff;
              font-size: 8px;
              font-weight: 800;
              white-space: nowrap;
            }

            .type-chip.credit,
            .credit-text {
              color: #17613a;
            }

            .type-chip.debit,
            .debit-text {
              color: #92402f;
            }

            .number-cell,
            .money-cell {
              text-align: right;
              white-space: nowrap;
            }

            .balance-cell {
              color: #111827;
              font-weight: 800;
            }

            .footer {
              margin-top: 10px;
              color: #64748b;
              font-size: 9px;
              text-align: right;
            }

            @media print {
              body {
                background: #ffffff;
              }

              .print-shell {
                width: auto;
                min-height: auto;
                margin: 0;
                padding: 0;
              }

              .print-toolbar {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <main class="print-shell">
            <div class="print-toolbar">
              <button type="button" onclick="window.print()">Save / Print PDF</button>
            </div>

            <header class="pdf-header">
              <div>
                <span class="pdf-kicker">Account ledger</span>
                <h1>${p(n)}</h1>
                <div class="pdf-meta">Generated ${p(e)} / ${_.length} entries</div>
              </div>
              <div class="balance-box">
                <span>Current balance</span>
                <strong>PKR ${p(c(t?.balance_due))}</strong>
              </div>
            </header>

            <section class="summary-grid">
              <div class="summary-card">
                <span>Stock quantity</span>
                <strong>${v.stockQuantity}</strong>
              </div>
              <div class="summary-card">
                <span>Debit</span>
                <strong>PKR ${p(c(v.debit))}</strong>
              </div>
              <div class="summary-card">
                <span>Credit</span>
                <strong>PKR ${p(c(v.credit))}</strong>
              </div>
              <div class="summary-card">
                <span>Net balance</span>
                <strong>PKR ${p(c(t?.balance_due))}</strong>
              </div>
            </section>

            <table>
              <colgroup>
                <col style="width: 86px" />
                <col style="width: 88px" />
                <col style="width: 132px" />
                <col style="width: 44px" />
                <col style="width: 76px" />
                <col style="width: 78px" />
                <col style="width: 78px" />
                <col style="width: 78px" />
                <col style="width: 86px" />
                <col />
              </colgroup>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Product</th>
                  <th>Qty</th>
                  <th>Unit</th>
                  <th>Total</th>
                  <th>Debit</th>
                  <th>Credit</th>
                  <th>Balance</th>
                  <th>Reference / note</th>
                </tr>
              </thead>
              <tbody>${i}</tbody>
            </table>

            <div class="footer">A4 landscape ledger / ${p(n)}</div>
          </main>
          <script>
            (function () {
              var printed = false;
              function printOnce() {
                if (printed) return;
                printed = true;
                window.focus();
                window.print();
              }

              window.addEventListener("load", function () {
                var images = Array.prototype.slice.call(document.images || []);
                if (!images.length) {
                  setTimeout(printOnce, 250);
                  return;
                }

                var remaining = images.length;
                function done() {
                  remaining -= 1;
                  if (remaining <= 0) setTimeout(printOnce, 350);
                }

                images.forEach(function (image) {
                  if (image.complete) {
                    done();
                    return;
                  }
                  image.addEventListener("load", done, { once: true });
                  image.addEventListener("error", done, { once: true });
                });

                setTimeout(printOnce, 3000);
              });
            })();
          <\/script>
        </body>
      </html>`,o=window.open(``,`_blank`);if(!o){alert(`Allow popups to export the PDF ledger.`);return}o.document.open(),o.document.write(a),o.document.close()},type:`button`,children:`Export PDF`})]})]}),d&&(0,s.jsx)(`div`,{className:`supplier-ledger-notice`,role:`status`,children:d}),i?(0,s.jsx)(`div`,{className:`supplier-ledger-empty`,children:`Loading account ledger...`}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`section`,{className:`supplier-ledger-summary`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{children:`Stock quantity`}),(0,s.jsx)(`strong`,{children:v.stockQuantity})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{children:`Debit`}),(0,s.jsxs)(`strong`,{children:[`PKR `,c(v.debit)]})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{children:`Credit`}),(0,s.jsxs)(`strong`,{children:[`PKR `,c(v.credit)]})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`span`,{children:`Balance`}),(0,s.jsxs)(`strong`,{children:[`PKR `,c(t?.balance_due)]})]})]}),_.length?(0,s.jsx)(`section`,{className:`supplier-ledger-table-panel`,children:(0,s.jsx)(`div`,{className:`supplier-ledger-table-wrap`,children:(0,s.jsxs)(`table`,{className:`supplier-ledger-table`,children:[(0,s.jsx)(`thead`,{children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{children:`Date`}),(0,s.jsx)(`th`,{children:`Ledger type`}),(0,s.jsx)(`th`,{children:`Product`}),(0,s.jsx)(`th`,{children:`Qty`}),(0,s.jsx)(`th`,{children:`Unit price`}),(0,s.jsx)(`th`,{children:`Total`}),(0,s.jsx)(`th`,{children:`Debit`}),(0,s.jsx)(`th`,{children:`Credit`}),(0,s.jsx)(`th`,{children:`Balance`}),(0,s.jsx)(`th`,{children:`Reference`})]})}),(0,s.jsx)(`tbody`,{children:_.map(e=>(0,s.jsxs)(`tr`,{className:`supplier-ledger-row is-${e.sourceType}`,children:[(0,s.jsx)(`td`,{children:r(e.date)}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`supplier-ledger-type is-${e.sourceType}`,children:e.ledgerType})}),(0,s.jsx)(`td`,{children:e.sourceType===`stock`?(0,s.jsxs)(`div`,{className:`supplier-ledger-product`,children:[e.thumbnailUrl?(0,s.jsx)(`img`,{src:e.thumbnailUrl,alt:e.sku}):(0,s.jsx)(`span`,{className:`supplier-ledger-noimg`,children:`No image`}),(0,s.jsx)(`strong`,{children:e.sku})]}):(0,s.jsx)(`span`,{className:`supplier-ledger-event-product`,children:`-`})}),(0,s.jsx)(`td`,{children:e.quantityLabel}),(0,s.jsx)(`td`,{children:e.unitPrice?`PKR ${c(e.unitPrice)}`:`-`}),(0,s.jsxs)(`td`,{children:[`PKR `,c(e.total)]}),(0,s.jsx)(`td`,{className:`supplier-ledger-debit`,children:e.debit?`PKR ${c(e.debit)}`:`-`}),(0,s.jsx)(`td`,{className:`supplier-ledger-credit`,children:e.credit?`PKR ${c(e.credit)}`:`-`}),(0,s.jsx)(`td`,{children:(0,s.jsxs)(`strong`,{children:[`PKR `,c(e.balance)]})}),(0,s.jsxs)(`td`,{children:[(0,s.jsx)(`span`,{children:e.reference}),e.note&&(0,s.jsx)(`small`,{children:e.note})]})]},e.id))})]})})}):(0,s.jsx)(`div`,{className:`supplier-ledger-empty`,children:`No ledger activity has been recorded for this account.`})]})]})};export{g as default};